<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('usecases.add')); ?></h3>
        </div>

        <div class="row col-sm-offset-1">
            <div class="col-md-12">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($lang->id==1?'active':''); ?>"><a href="#tab<?php echo e($lang->id); ?>" data-toggle="tab"
                                                                        aria-expanded="true"><?php echo e($lang->lang); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <form role="form" action="<?php echo e(route('usecasesStore')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="tab-content">
                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane <?php echo e($lang->id==1 ?'active':''); ?>" id="tab<?php echo e($lang->id); ?>">
                                    <div class="form-group <?php echo e($errors->has('name_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('usecases.title')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="name_<?php echo e($lang->lang); ?>"
                                               placeholder="<?php echo e(trans('Please Enter Solution Name')); ?>"
                                               value="<?php echo e(old('name_'.$lang->lang)); ?>"
                                        >
                                        <?php $__errorArgs = ['name_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('description_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="description"><?php echo e(trans('usecases.description')); ?></label>
                                        <textarea
                                            class="form-control"
                                            id="description" name="description_<?php echo e($lang->lang); ?>"><?php echo e(old('description_'.$lang->lang)); ?></textarea>
                                        <?php $__errorArgs = ['description_'.$lang->lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('challenges_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="description"><?php echo e(trans('usecases.challenges')); ?></label>
                                        <textarea
                                            class="form-control"
                                            id="challenges" name="challenges_<?php echo e($lang->lang); ?>"><?php echo e(old('challenges_'.$lang->lang)); ?></textarea>
                                        <?php $__errorArgs = ['challenges_'.$lang->lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('opportunities_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="description"><?php echo e(trans('usecases.opportunities')); ?></label>
                                        <textarea
                                            class="form-control"
                                            id="description" name="opportunities_<?php echo e($lang->lang); ?>"><?php echo e(old('opportunities_'.$lang->lang)); ?></textarea>
                                        <?php $__errorArgs = ['opportunities_'.$lang->lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('whyWakeb_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="description"><?php echo e(trans('usecases.whyWakeb')); ?></label>
                                        <textarea
                                            class="form-control"
                                            id="description" name="whyWakeb_<?php echo e($lang->lang); ?>"><?php echo e(old('whyWakeb_'.$lang->lang)); ?></textarea>
                                        <?php $__errorArgs = ['whyWakeb_'.$lang->lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('img') ? 'has-error' : ''); ?>">
                            <label for="image"><?php echo e(trans('solutions.img')); ?></label>
                            <input type="file" id="image" name="img">
                            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(trans('usecases.solution')); ?></label>
                            <select class="form-control select2 select2-hidden-accessible" name="solution"
                                    style="width: 100%;" tabindex="-1" aria-hidden="true">
                                <option disabled selected><?php echo e(trans('usecases.solution')); ?></option>
                                <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($solution->id); ?>"><?php echo e($solution->trans_lang->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="box-footer">
                            <button type="submit"
                                    class="btn btn-primary"><?php echo e(trans('usecases.add')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if(session()->has('message')): ?>
        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                onOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            Toast.fire({
                icon: 'success',
                title: '<?php echo e(trans('solutions.added')); ?>'
            })
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/admin/useCases/create.blade.php ENDPATH**/ ?>