<div class=" mb-5 rased-animate">
    <img src="<?php echo e(asset('assets/images/products/rased/rased1.svg')); ?>" class="rased1 flipInY animated wow " style="animation-delay: 0..25s">
    <img src="<?php echo e(asset('assets/images/products/rased/rased2.svg')); ?>" class="rased2 fadeInRight animated wow " style="animation-delay: 0.5s">
    <img src="<?php echo e(asset('assets/images/products/rased/rased3.svg')); ?>" class="rased3 fadeInLeft animated wow " style="animation-delay: 0.5s">
    <img src="<?php echo e(asset('assets/images/products/rased/rased4.svg')); ?>" class="rased4 fadeInLeft animated wow " style="animation-delay: 0.5s">
    <span class="rased5 fadeInDown animated wow " style="animation-delay: 0.75s">Happy</span>
    <span class="rased6 fadeInDown animated wow " style="animation-delay: 0.75s">Sad</span>
    <span class="rased7 fadeInDown animated wow " style="animation-delay: 0.75s">Natural</span>
</div>
<?php /**PATH C:\laragon\www\wakeb\resources\views/FrontEnd/products/rasad.blade.php ENDPATH**/ ?>