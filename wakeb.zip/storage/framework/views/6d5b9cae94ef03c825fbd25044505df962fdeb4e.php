<div class="image-analysis mb-5">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis1.svg')); ?>" class="image-analysis1 fadeInRight animated wow " style="animation-delay: 0.25s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis2.svg')); ?>" class="image-analysis2 fadeInLeft animated wow " style="animation-delay: 0.75s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis5.svg')); ?>" class="image-analysis5 fadeIn animated wow " style="animation-delay: 1s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis6.svg')); ?>" class="image-analysis6 fadeIn animated wow " style="animation-delay: 1.25s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis7.svg')); ?>" class="image-analysis7 fadeIn animated wow " style="animation-delay: 1.5s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis8.svg')); ?>" class="image-analysis8 fadeIn animated wow " style="animation-delay: 1.75s">
    <img src="<?php echo e(asset('assets/images/products/imageAnalysis/imgAnalysis9.svg')); ?>" class="image-analysis9 fadeIn animated wow " style="animation-delay: 2s">
</div>
<?php /**PATH C:\laragon\www\wakeb\resources\views/FrontEnd/products/imganalysis.blade.php ENDPATH**/ ?>