<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <!-- Profile Image -->
        <div class="box box-primary">
            <div class="box-body box-profile">

                <h3 class="profile-username text-center"><?php echo e($message->name); ?></h3>

                <p class="text-muted text-center"><?php echo e($message->phone); ?></p>

                <h2><?php echo e($message->message); ?></h2>
                <h2><?php if($message->read): ?>
                        Done Reading
                    <?php else: ?>
                        Not Read
                    <?php endif; ?>
                </h2>
            </div>
            <!-- /.box-body -->
            <?php if(!$message->read): ?>
                <form action="<?php echo e(route('markAsRead', $message)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary" type="submit">Done</button>
                </form>
            <?php endif; ?>
        </div>
        <!-- /.box -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>