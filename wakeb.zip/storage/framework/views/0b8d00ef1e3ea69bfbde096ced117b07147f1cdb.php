<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('solutions.deleted')); ?></h3>

            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title=""
                        data-original-title="Collapse">
                    <i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title=""
                        data-original-title="Remove">
                    <i class="fa fa-times"></i></button>
            </div>
        </div>
        <div class="box-body">
            <div class="box">
                <div class="box-body">
                    <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                        <div class="row">
                            <div class="col-sm-6"></div>
                            <div class="col-sm-6"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <table id="example1" class="table table-bordered table-hover dataTable" role="grid"
                                       aria-describedby="example2_info">
                                    <thead>
                                    <tr role="row">
                                        <th><?php echo e(trans('solutions.id')); ?></th>
                                        <th><?php echo e(trans('solutions.img')); ?></th>
                                        <th class="sorting_asc" tabindex="0" aria-controls="example2" rowspan="1"
                                            colspan="1"
                                            aria-sort="ascending"
                                            aria-label="Rendering engine: activate to sort column descending"><?php echo e(trans('solutions.name')); ?>

                                        </th>
                                        <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                                            colspan="1"
                                            aria-label="Browser: activate to sort column ascending"><?php echo e(trans('solutions.description')); ?>

                                        </th>
                                        <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1"
                                            colspan="1"
                                            aria-label="Platform(s): activate to sort column ascending"><?php echo e(trans('solutions.action')); ?>

                                        </th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr role="row" class="odd">
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><img style="width: 30px;height: 30px;"
                                                     src="<?php echo e(asset($solution->img_url)); ?>" alt=""></td>
                                            <td class="sorting_1"><?php echo e($solution->trans_lang->name); ?></td>
                                            <td><?php echo e($solution->trans_lang->description); ?></td>
                                            <td>
                                                <button class="btn btn-primary glyphicon glyphicon-ok"
                                                        data-toggle="tooltip"
                                                        data-placement="top"
                                                        onclick="restoreSolution(<?php echo e($solution->id); ?>)"
                                                        id="restore<?php echo e($solution->id); ?>"
                                                        title="<?php echo e(trans('products.restoreUser')); ?>">
                                                </button>
                                                <button onclick="softDelete(<?php echo e($solution->id); ?>)"
                                                        class="glyphicon glyphicon-remove btn btn-danger"
                                                        data-toggle="tooltip"
                                                        data-placement="top"
                                                        title="<?php echo e(trans('products.deleteForEver')); ?>"
                                                        id="<?php echo e($solution->id); ?>">
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <th>#id</th>
                                        <th><?php echo e(trans('products.productImage')); ?></th>
                                        <th rowspan="1" colspan="1"><?php echo e(trans('products.productName')); ?></th>
                                        <th rowspan="1" colspan="1"><?php echo e(trans('products.productDescription')); ?></th>
                                        <th rowspan="1" colspan="1"><?php echo e(trans('products.action')); ?></th>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(function () {
            $('#example1').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false
            })
        })
    </script>

    <script>
        function restoreSolution(id) {
            console.log(id)
            axios({
                method: 'post',
                url: '<?php echo e(route('solutionRestore')); ?>',
                data: {
                    id: id,
                    _token: "<?php echo e(csrf_token()); ?>"
                }
            }).then((res) => {
                console.log(res.data);
                $('#restore' + id).parent().parent().remove();
            });
        }

        function softDelete(id) {
            Swal.fire({
                title: 'Delet User',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                preConfirm: () => {
                    axios({
                        method: 'delete',
                        url: '<?php echo e(route('solutionForceDelete')); ?>',
                        data: {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>",
                        }
                    }).then((res) => {
                        console.log(res.data)
                        $('#' + id).parent().parent().remove();
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 3000,
                            timerProgressBar: true,
                            onOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })

                        Toast.fire({
                            icon: 'success',
                            title: '<?php echo e(trans('solutions.deletedSuccessfully')); ?>'
                        })
                    });
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/admin/solutions/deleted.blade.php ENDPATH**/ ?>