<?php $__env->startSection('content'); ?>
    <div class="single-service  sec-pt  ">
        <div class="container mt-lg">
            <div class="row mb-5">
                <div class="col-sm-12 text-center">
                    <div class="title"><?php echo e($service->service_trans_lang->name); ?></div>
                </div>
            </div>
        </div>
        <section class="py-5 scroll" id="section1">
            <div class="container">
                <div class="media mb-5">
                    <div class="mr-5 media-image">
                        <img src="<?php echo e(asset($service->img_url)); ?>" alt="" max-width="100%">
                    </div>
                    <div class="media-body">
                        <h3 class="mt-0 font-weight-bold text-uppercase"><?php echo e(trans('About')); ?></h3>
                        <p><?php echo $service->service_trans_lang->description; ?></p>
                    </div>
                </div>
            </div>
        </section>
        <section class="light-bg sec-padding scroll" id="section2">
            <div class="container pb-5">
                <h3 class="font-weight-bold mb-5"><?php echo e(trans('features.features')); ?></h3>
                <div class="row">
                    <?php $__currentLoopData = $service->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-5">
                            <h3 class="side-title font-weight-bold"><?php echo e($feature->feature_trans_lang->name); ?></h3>
                            <p><?php echo $feature->feature_trans_lang->description; ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
        <section class="sec-padding scroll" id="section3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-5">
                            <h3 class="font-weight-bold text-uppercase"></h3>
                            <p></p>
                        </div>
                        <div class="mb-5">
                            <h3 class="font-weight-bold text-uppercase"></h3>
                            <p></p>
                        </div>
                    </div>
                    <div class="col-md-5 offset-md-1">
                        <div class="side-img-bg">
                            <img src="<?php echo e(asset('assets/images/service2-1.jpg')); ?>" alt="">
                            <span class="bg"></span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="sec-padding scroll" id="section4">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="title"><?php echo e(trans('Schedule a meeting with us')); ?></h3>
                        <p></p>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <form action="<?php echo e(route('contactUs')); ?>" method="post" class="col-lg-8 offset-lg-2">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" id="name" aria-describedby="nameHelp"
                                           placeholder="" name="name">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp"
                                           placeholder="" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="number" class="form-control" id="phone" aria-describedby="nameHelp"
                                           placeholder="" name="phone">
                                </div>
                                <button type="submit" class="btn  btn-lg btn-block send">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <ul class="fixedslider">
            <li><a href="#section1" class="active"></a></li>
            <li><a href="#section2"></a></li>
            <li><a href="#section3"></a></li>
            <li><a href="#section4"></a></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FrontEnd.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/FrontEnd/services/show.blade.php ENDPATH**/ ?>