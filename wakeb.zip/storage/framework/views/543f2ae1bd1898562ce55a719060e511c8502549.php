<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <!-- Profile Image -->
        <div class="box box-primary">
            <div class="box-body box-profile">
                <img class="img-responsive img-circle" style="margin: 0 auto; width: 100px;height: 100px;"
                     src="<?php echo e(asset($service->img_url)); ?>" alt="User profile picture">

                <h3 class="profile-username text-center"><?php echo e($service->service_trans_lang->name); ?></h3>

                <p class="text-muted text-center"><?php echo e($service->service_trans_lang->description); ?></p>

                <ul class="list-group list-group-unbordered">
                    <?php $__currentLoopData = $service->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col-md-6">
                                    <b><?php echo e($feature->feature_trans_lang[0]->name); ?></b>
                                </div>
                                <div class="col-md-6">
                                    <button class="btn btn-primary glyphicon glyphicon-remove">
                                    </button>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/admin/services/show.blade.php ENDPATH**/ ?>