<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Wakeb</title>
    <?php $locale = session()->get('locale'); ?>

    <?php if($locale=='en'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <?php endif; ?>
    <?php if($locale=='ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.rtl.min.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/home.css')); ?>">
    <?php if($locale=='ar'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.rtl.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cairo&display=swap">
</head>
<body>
<!-- Loading Animation-->
<div id="layout-loading">
    <img src="<?php echo e(asset('assets/images/wakeb-logo.svg')); ?>" class="wakeb">
    <div class="loader-effect"></div>
</div>

<div id="wrap">
    <!-- menu -->
    <div id="menu">
        <div class="container-fluid">
            <div class="navigation">
                <a class="navbar-brand brand-logo" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('assets/images/wakeb-logo.svg')); ?>" alt="Wakeb" title="Wakeb">
                </a>
                <span id="toggle-menu">Menu</span>
            </div>
        </div>
        <div id="menu-content">
            <div class="container-fluid menu-list">
                <ul>
                    <li>

                        <?php switch($locale):
                            case ('en'): ?>
                            <a href="<?php echo e(route('changeLang', 'ar')); ?>" class="mb-2 font-weight-normal">
                                <img src="<?php echo e(asset('assets/images/lang.png')); ?>" class="mr-1" width="22px">
                                <span>العربية</span>
                            </a>
                            <?php break; ?>
                            <?php case ('ar'): ?>
                            <a href="<?php echo e(route('changeLang', 'en')); ?>" class="mb-2 font-weight-normal">
                                <img src="<?php echo e(asset('assets/images/lang.png')); ?>" class="mr-1" width="22px">
                                <span>English</span>
                            </a>
                            <?php break; ?>
                            <?php default: ?>
                            <a href="<?php echo e(route('changeLang', 'ar')); ?>" class="mb-2 font-weight-normal">
                                <img src="<?php echo e(asset('assets/images/lang.png')); ?>" class="mr-1" width="22px">
                                <span>العربية</span>
                            </a>
                        <?php endswitch; ?>
                    </li>
                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>"><?php echo e(trans('Home')); ?></a>
                    </li>
                    <li class="has-menu">
                        <a><?php echo e(trans('products.products')); ?></a>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('showProductFront', $product)); ?>"><?php echo e($product->product_trans_lang[0]->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="has-menu">
                        <a><?php echo e(trans('services.services')); ?></a>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="service-1.html"><?php echo e($service->service_trans_lang[0]->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="has-menu">
                        <a><?php echo e(trans('solutions.solutions')); ?></a>
                        <ul class="sub-menu">
                            <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="solution-9.html"><?php echo e($solution->trans_lang[0]->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo e(route('about')); ?>"><?php echo e(trans('About us')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('contact')); ?>"><?php echo e(trans('Contact us')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--/. menu -->

    <!-- product  -->
    <?php echo $__env->yieldContent('content'); ?>

    <footer class="footer">
        <div class="container-fluid">
            <ul>
                <li>
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li>
                    <a href="products.html"><?php echo e(trans('products.products')); ?></a>
                </li>
                <li>
                    <a href="services.html"><?php echo e(trans('services.services')); ?></a>
                </li>
                <li>
                    <a href="solutions.html">Solutions</a>
                </li>
                <li>
                    <a href="blogs.html">Blog</a>
                </li>
                <li>
                    <a href="<?php echo e(route('about')); ?>"><?php echo e(trans('About us')); ?></a>
                </li>
                <li>
                    <a href="<?php echo e(route('contact')); ?>"><?php echo e(trans('Contact us')); ?></a>
                </li>
            </ul>
            <ul class="list">
                <li>
                    <a target="_blank" href="https://www.facebook.com/Wakeb.tech/"><i class="fa fa-facebook"
                                                                                      title="facebook"></i></a>
                </li>
                <li>
                    <a target="_blank" href="https://www.linkedin.com/company/wakeb-data"><i class="fa fa-linkedin"
                                                                                             title="linkedin"></i></a>
                </li>
                <li>
                    <a target="_blank" href="https://twitter.com/WAKEB_Data"><i class="fa fa-twitter"
                                                                                title="twitter"></i></a>
                </li>
                <li><a target="_blank" href="https://www.instagram.com/wakeb.data/" title="instagram"><i
                            class="fa fa-instagram"></i></a>
                </li>
            </ul>
            <p>Wakeb © 2019, All copyrights reserved</p>
        </div>
    </footer>
    <!--/. Footer  -->

</div>

<!--jquery-->
<script src="<?php echo e(asset('assets/js/jquery-min.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- slick JS -->
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<!-- WOW JS -->
<script src="<?php echo e('assets/js/wow.min.js'); ?>"></script>
<script>
    new WOW().init();
</script>
<!-- functions JS -->
<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\wakeb\resources\views/FrontEnd/layout/loyoutForProSer.blade.php ENDPATH**/ ?>