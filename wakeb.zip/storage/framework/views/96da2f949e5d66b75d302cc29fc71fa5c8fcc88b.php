<div class="mb-5 nasih-animate"><img src="<?php echo e(asset('assets/images/products/nasih/nasih1.svg')); ?>"
                                     class="nasih1 jackInTheBox animated wow "
                                     style="animation-delay: 0.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih2.svg')); ?>" class="nasih2 pulse animated wow "
         style="animation-delay: 0.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih3.svg')); ?>" class="nasih3 fadeInUp animated wow "
         style="animation-delay: 0.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih4.svg')); ?>" class="nasih4 flash animated wow "
         style="animation-delay: 1.5s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih5.svg')); ?>" class="nasih5 flash animated wow "
         style="animation-delay: 1.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih6.svg')); ?>" class="nasih6 flash animated wow "
         style="animation-delay: 1.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih7.svg')); ?>" class="nasih7 flash animated wow "
         style="animation-delay: 1.75s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih8.svg')); ?>" class="nasih8 zoomIn animated wow "
         style="animation-delay: 2s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih9.svg')); ?>" class="nasih9 zoomIn animated wow "
         style="animation-delay: 2.5s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih10.svg')); ?>" class="nasih10 fadeIn animated wow "
         style="animation-delay: 2s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih11.svg')); ?>" class="nasih11 zoomIn animated wow "
         style="animation-delay: 2.25s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih12.svg')); ?>" class="nasih12 flash animated wow "
         style="animation-delay: 2.40">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih13.svg')); ?>" class="nasih13 flash animated wow "
         style="animation-delay: 3s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih14.svg')); ?>" class="nasih14 fadeIn animated wow "
         style="animation-delay: 2s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih15.svg')); ?>" class="nasih15 zoomIn animated wow "
         style="animation-delay: 1.5s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih16.svg')); ?>" class="nasih16 zoomIn animated wow "
         style="animation-delay: 1.5s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih17.svg')); ?>" class="nasih17 zoomIn animated wow "
         style="animation-delay: 2s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih18.svg')); ?>" class="nasih18 fadeInLeft animated wow "
         style="animation-delay: 1s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih19.svg')); ?>" class="nasih19 fadeInRight animated wow "
         style="animation-delay: 1s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih20.svg')); ?>" class="nasih20 flash animated wow "
         style="animation-delay: 2s">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih21.svg')); ?>" class="nasih21 flash animated wow "
         style="animation-delay: 1.5">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih22.svg')); ?>" class="nasih22 flash animated wow "
         style="animation-delay: 1.75">
    <img src="<?php echo e(asset('assets/images/products/nasih/nasih23.svg')); ?>" class="nasih23 flash animated wow "
         style="animation-delay: 2s"></div>
<?php /**PATH C:\laragon\www\wakeb\resources\views/FrontEnd/products/nasih.blade.php ENDPATH**/ ?>