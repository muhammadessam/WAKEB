<?php $__env->startSection('content'); ?>


    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('About')); ?></h3>
        </div>

        <div class="row col-sm-offset-1">
            <div class="col-md-6">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($lang->id==1?'active':''); ?>"><a href="#tab<?php echo e($lang->id); ?>" data-toggle="tab"
                                                                        aria-expanded="true"><?php echo e($lang->lang); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <form role="form" action="<?php echo e(route('saveAbout')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="tab-content">
                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane <?php echo e($lang->id==1 ?'active':''); ?>" id="tab<?php echo e($lang->id); ?>">
                                    <div class="form-group <?php echo e($errors->has('title_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('Title')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="name_<?php echo e($lang->lang); ?>"
                                               <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($about->lang_id==$lang->id): ?> value="<?php echo e($about->title); ?>" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        <?php $__errorArgs = ['name_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('about_us_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('About us')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="about_us_<?php echo e($lang->lang); ?>"
                                               <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($about->lang_id==$lang->id): ?> value="<?php echo e($about->about_us); ?>" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        <?php $__errorArgs = ['about_us_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('our_goals_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('Our Goals')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="our_goals_<?php echo e($lang->lang); ?>"
                                               <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($about->lang_id==$lang->id): ?> value="<?php echo e($about->our_goals); ?>" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        <?php $__errorArgs = ['our_goals_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('vision_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('Vision')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="vision_<?php echo e($lang->lang); ?>"
                                               <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($about->lang_id==$lang->id): ?> value="<?php echo e($about->vision); ?>" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        <?php $__errorArgs = ['vision_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div
                                        class="form-group <?php echo e($errors->has('how_we_work_'.$lang->lang) ? 'has-error' : ''); ?>">
                                        <label for="productName"><?php echo e(trans('How We Work')); ?></label>
                                        <input type="text" class="form-control" id="productName"
                                               name="how_we_work_<?php echo e($lang->lang); ?>"
                                               <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($about->lang_id==$lang->id): ?> value="<?php echo e($about->how_we_work); ?>" <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                        <?php $__errorArgs = ['how_we_work_'.$lang->$lang];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="box-footer">
                            <button type="submit"
                                    class="btn btn-primary"><?php echo e(trans('Save')); ?></button>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wakeb\resources\views/admin/about/index.blade.php ENDPATH**/ ?>