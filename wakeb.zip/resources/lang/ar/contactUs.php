<?php
return [
    'contactUS'=>'اتصل بنا',
    'Messages'=>"الرسائل"

];
