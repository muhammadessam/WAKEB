<?php
return [
    'sliders'=>'المنزلق',




];
