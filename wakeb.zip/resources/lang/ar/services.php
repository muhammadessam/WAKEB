<?php
return[
    'action'=>'اجراء',
    'services' => 'الخدمات',
    'servicesShowAll' => 'كل الخدمات',
    'servicesAdd' => 'اضافة خدمة',
    'servicesRemove' => 'حذف الخدمة',
    'servicesRemoved' => 'الخدمات المحذوفة',
    'serviceName'=>'اسم الخدمة',
    'serviceDescription'=>'وصف الخدمة',
    'serviceEdit'=>'تعديل الخدمة',
    'serviceAddSuccessfully'=>'تم اضافة الخدمة بنجاح',
    'serviceImage'=>'صورة الخدمة',
    'serviceNameEnter_ar'=>'من فضلك ادخل اسم الخدمة باللغة العربية',
    'serviceDescriptionEnter_ar'=>'من فضلك ادخل وصف الخدمة باللغة العربية',
    'serviceNameEnter_en'=>'من فضلك ادخل اسم الخدمة باللغة الانجليزية',
    'serviceDescriptionEnter_en'=>'من فضلك ادخل وصف الخدمة باللغة الانجليزية',
    'serviceDoneRemoving'=>'تم حذف الخدمة',
    'serviceImage'=>'صورة الخدمة'
];
