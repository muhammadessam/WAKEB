<?php
return [
    'features'=>'المميزات',
    'all'=>'كل المميزات',
    'Add'=>'اضف ميزة',
    'Added'=>'تم اضافة ميزة',
    'delete'=>'حذف ميزة',
    'deleted'=>'المميزات المحذوفة',
    'doneDeleted'=>'تم حذف الميزة',
    'description'=>'الوصف',
    'action'=>'اجراء',
    'id'=>'م',
    'name'=>'ألاسم',
    'type'=>'النوع',
    'success'=>'تم الاضافة بنجاح',
    'service'=>'خدمة',
    'product'=>'منتج',


];
