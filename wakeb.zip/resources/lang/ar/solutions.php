<?php
return [
    'solutions'=>'الحلول',
    'showAll' =>'كل الحلول',
    'img'=>'الصورة',
    'name'=>'الاسم',
    'description'=>'الوصف',
    'action'=>'اجراء',
    'id'=>'م',
    'add'=>'اصف حل',
    'added'=>'تم اضافة الحل بنجاح',
    'edit'=>'تعديل الحل',
    'deletedSuccessfully'=>'تم الحذف بنجاح',
    'deleted' => 'الحلول المحذوفة',

];
