<?php
return[
    'action'=>'اجراء',
    'products' => 'المنتجات',
    'productsShowAll' => 'كل المنتجات',
    'productsAdd' => 'اضافة منتج',
    'productsRemove' => 'حذف المنتج',
    'productsRemoved' => 'المنتجات المحذوفة',
    'productName'=>'اسم المنتج',
    'productDescription'=>'وصف المنتج',
    'productEdit'=>'تعديل المنتج',
    'productAddSuccessfully'=>'تم اضافة المنتج بنجاح',
    'productImage'=>'صورة المنتج',
    'productNameEnter_ar'=>'من فضلك ادخل اسم المنتح باللغة العربية',
    'productDescriptionEnter_ar'=>'من فضلك ادخل وصف المنتج باللغة العربية',
    'productNameEnter_en'=>'من فضلك ادخل اسم المنتح باللغة الانجليزية',
    'productDescriptionEnter_en'=>'من فضلك ادخل وصف المنتج باللغة الانجليزية',
    'productDoneRemoving'=>'تم حذف المنتج',
    'productImage'=>'صورة المنتج'
];
