<?php
return [
    'usecase'=>'الامثلة',
    'showAll'=>'عرض الكل',
    'add'=>'اضف',
    'edit'=>'تعديل',
    'delete'=>'حذف',
    'deleted'=>'المحذوف',
    'challenges'=>'التحديات',
    'opportunities'=>'الفرص',
    'whyWakeb'=>'لماذا واكب',
    'title'=>'الاسم',
    'description'=>'الوصف',
    'solution'=>'الحلول',

];
