<?php
return [
    'solutions' => 'Solutions',
    'showAll' => 'Show All',
    'img' => 'Image',
    'name' => 'Name',
    'description' => 'Description',
    'action' => 'Action',
    'id' => 'ID',
    'add' => 'Add Solution',
    'added' => 'Solution Added Successfully',
    'edit' => 'Edit Solution',
    'deletedSuccessfully' => 'Successfully Deleted',
    'deleted' => 'Deleted Solutions',

];
