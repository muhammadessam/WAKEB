<?php
return [
    'usecase'=>'Use Case',
    'showAll'=>'Show all',
    'add'=>'Add',
    'edit'=>'Edit',
    'delete'=>'Delete',
    'deleted'=>'Deleted',
    'challenges'=>'Challenges',
    'opportunities'=>'Opportunities',
    'whyWakeb'=>'Why Wakeb',
    'title'=>'Title',
    'description'=>'Description',
    'solution'=>'Solution',

];
