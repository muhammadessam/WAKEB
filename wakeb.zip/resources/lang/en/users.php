<?php
return [
    'controlPanel'=>'Control Panel',
    'welcome' => "Hello",
    'users' => "Users",
    'showAll'=>'Show All',
    'addUser' => 'Add User',
    'editUser' => 'Edit User',
    'deleteUser' => 'Delete User',
    'userName'=>'Name',
    'userPhone'=>'Phone',
    'userEmail'=>'Email',
    'userAction' => 'Actions',
    'userPassword' => 'Password',
    'rest' => 'Rest',
    'userAddedSuccessfully' => 'User Added Successfully',
    'cannotRemoveUser' => 'User is logged in',
    'userRemoved' => 'User Removed',
    'deletedUsers' => 'Deleted Users',
    'restoreUser' => 'Restore User',
    'deleteForEver' => 'Delete For Ever',
    'modify'=>'Modify User',

];
