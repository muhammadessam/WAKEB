<?php
return [
    'features' => 'features',
    'all' => 'All features',
    'Add' => 'Add Feature',
    'Added' => 'Feature Added Successfully',
    'delete' => 'Delete Feature',
    'deleted' => 'All Deleted Features',
    'doneDeleted'=>'Feature Deleted Successfully',
    'description'=>'Description',
    'action'=>'Action',
    'id'=>'ID',
    'name'=>'Name',
    'type'=>'Type',
    'success'=>'Feature Added Successfully',
    'service'=>'Service',
    'product'=>'Product',
];
