<div class="mb-5 predictive-animate"><img src="{{asset('assets/images/products/predictiveAnalysis/predictive1.svg')}}"
                                          class="predictive1 fadeInDown animated wow " style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive2.svg')}}"
         class="predictive2 fadeInUp animated wow " style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive3.svg')}}"
         class="predictive3 fadeInDown animated wow " style="animation-delay: 0.5s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive4.svg')}}"
         class="predictive4 fadeInRight animated wow " style="animation-delay: 1.25s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive5.svg')}}"
         class="predictive5 fadeInLeft animated wow " style="animation-delay: 1.5s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive6.svg')}}"
         class="predictive6 fadeInLeft animated wow " style="animation-delay: 1.5s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive7.svg')}}"
         class="predictive7 fadeInDown animated wow " style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive8.svg')}}"
         class="predictive8 fadeInDown animated wow " style="animation-delay: 2.25s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive9.svg')}}"
         class="predictive9 fadeInDown animated wow " style="animation-delay: 2.5s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive10.svg')}}"
         class="predictive10 fadeInDown animated wow " style="animation-delay: 2.75s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive11.svg')}}"
         class="predictive11 fadeInDown animated wow " style="animation-delay: 2.25s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive12.svg')}}"
         class="predictive12 fadeInDown animated wow " style="animation-delay: 2.5s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive13.svg')}}"
         class="predictive13 fadeIn animated wow " style="animation-delay: 0.75s">
    <img src="{{asset('assets/images/products/predictiveAnalysis/predictive14.svg')}}"
         class="predictive14 fadeInDown animated wow " style="animation-delay: 2.75s">
</div>
