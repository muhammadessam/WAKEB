<div class=" mb-5 IPMS-animate">
    <img src="{{asset('assets/images/products/IPMS/IPMS1.svg')}}" class="IPMS1 fadeInRight animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/IPMS/IPMS2.svg')}}" class="IPMS2 fadeInLeft animated wow "
         style="animation-delay: 0.5s">
    <img src="{{asset('assets/images/products/IPMS/IPMS3.svg')}}" class="IPMS3 rotateInUpLeft animated wow "
         style="animation-delay: 1s; visibility: hidden;">
    <img src="{{asset('assets/images/products/IPMS/IPMS4.svg')}}" class="IPMS4 fadeIn animated wow "
         style="animation-delay: 1s">
    <img src="{{asset('assets/images/products/IPMS/IPMS5.svg')}}"
         class="IPMS5 animated-up-down fadeInDown animated wow "
         style="animation-delay: 1s">
    <img src="{{asset('assets/images/products/IPMS/IPMS6.svg')}}" class="IPMS6 rotateInDownRight animated wow "
         style="animation-delay: 1s">
    <img src="{{asset('assets/images/products/IPMS/IPMS7.svg')}}" class="IPMS7 fadeInUp animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/IPMS/IPMS8.svg')}}" class="IPMS8 fadeInLeft animated wow "
         style="animation-delay: 1.25s">
    <img src="{{asset('assets/images/products/IPMS/IPMS9.svg')}}" class="IPMS9 fadeInRight animated wow "
         style="animation-delay: 1.5s">
    <span class="fadeInUp animated wow " style="animation-delay: 1.75s">
                                    Intelligent</br>Personalized</br>Marketing</br>System</br>(IPMS)
                                </span>
</div>
