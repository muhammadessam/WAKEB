<div class=" mb-5 twittelab-animate">


    <img src="{{asset('assets/images/products/twittelab/twittelab1.svg')}}" class="twittelab1 fadeInLeft animated wow "
         style="animation-delay: 1.5s">
    <img src="{{asset('assets/images/products/twittelab/twittelab3.svg')}}" class="twittelab3 zoomIn animated wow "
         style="animation-delay: 3.30s">

    <img src="{{asset('assets/images/products/twittelab/twittelab4.svg')}}" class="twittelab4 zoomIn animated wow "
         style="animation-delay: 3s">
    <img src="{{asset('assets/images/products/twittelab/twittelab5.svg')}}" class="twittelab5 zoomIn animated wow "
         style="animation-delay: 3.20s">
    <img src="{{asset('assets/images/products/twittelab/twittelab6.svg')}}" class="twittelab6 fadeInDown animated wow "
         style="animation-delay: 0.45s">
    <img src="{{asset('assets/images/products/twittelab/twittelab7.svg')}}" class="twittelab7 fadeInRight animated wow "
         style="animation-delay: 0.30s">
    <img src="{{asset('assets/images/products/twittelab/twittelab8.svg')}}" class="twittelab8 fadeInRight animated wow "
         style="animation-delay: 1s">
    <img src="{{asset('assets/images/products/twittelab/twittelab9.svg')}}" class="twittelab9 fadeInDown animated wow "
         style="animation-delay: 0.5s">
    <img src="{{asset('assets/images/products/twittelab/twittelab10.svg')}}"
         class="twittelab10 fadeInDown animated wow " style="animation-delay: 0.75s">
    <img src="{{asset('assets/images/products/twittelab/twittelab11.svg')}}"
         class="twittelab11 fadeInLeft animated wow " style="animation-delay: 0.50s">
    <img src="{{asset('assets/images/products/twittelab/twittelab12.svg')}}" class="twittelab12 fadeIn animated wow "
         style="animation-delay: 1.70s">
    <img src="{{asset('assets/images/products/twittelab/twittelab13.svg')}}" class="twittelab13 zoomIn animated wow "
         style="animation-delay: 2.70s">
    <img src="{{asset('assets/images/products/twittelab/twittelab14.svg')}}" class="twittelab14 zoomIn animated wow "
         style="animation-delay: 2.30s">
    <img src="{{asset('assets/images/products/twittelab/twittelab15.svg')}}" class="twittelab15 zoomIn animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/twittelab/twittelab16.svg')}}" class="twittelab16 zoomIn animated wow "
         style="animation-delay: 2.55s">
    <img src="{{asset('assets/images/products/twittelab/twittelab17.svg')}}" class="twittelab17 fadeIn animated wow "
         style="animation-delay: 2.75s">
    <img src="{{asset('assets/images/products/twittelab/twittelab18.svg')}}" class="twittelab18 fadeInUp animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/twittelab/twittelab19.svg')}}" class="twittelab19 fadeIn animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/twittelab/twittelab20.svg')}}" class="twittelab20 fadeIn animated wow "
         style="animation-delay: 0.40s">
    <img src="{{asset('assets/images/products/twittelab/twittelab21.svg')}}"
         class="twittelab21 fadeInDown animated wow " style="animation-delay:2s">
    <img src="{{asset('assets/images/products/twittelab/twittelab22.svg')}}" class="twittelab22 fadeIn animated wow "
         style="animation-delay: 3s">
    <img src="{{asset('assets/images/products/twittelab/twittelab23.svg')}}" class="twittelab23 zoomIn animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/twittelab/twittelab24.svg')}}" class="twittelab24 zoomIn animated wow "
         style="animation-delay: 1.75s">
    <img src="{{asset('assets/images/products/twittelab/twittelab25.svg')}}" class="twittelab25 rollIn animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/twittelab/twittelab26.svg')}}" class="twittelab26 zoomIn animated wow "
         style="animation-delay: 3s">
    <img src="{{asset('assets/images/products/twittelab/twittelab27.svg')}}" class="twittelab27 rollIn animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/twittelab/twittelab28.svg')}}"
         class="twittelab28 fadeInLeft animated wow " style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/twittelab/twittelab29.svg')}}" class="twittelab29 fadeIn animated wow "
         style="animation-delay: 0.40s">
    <img src="{{asset('assets/images/products/twittelab/twittelab30.svg')}}"
         class="twittelab30 fadeInRight animated wow " style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/twittelab/twittelab31.svg')}}" class="twittelab31 zoomIn animated wow "
         style="animation-delay: 0.50s">
    <img src="{{asset('assets/images/products/twittelab/twittelab32.svg')}}"
         class="twittelab32 fadeInRight animated wow " style="animation-delay: 0.75s">
</div>
