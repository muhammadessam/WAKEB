<div class="mb-5 masbar-animate">
    <img src="{{asset('assets/images/products/masbar/masbar-1.svg')}}" class="masbar1 fadeInUp animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/masbar/masbar-2.svg')}}" class="masbar2 fadeInRight animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/masbar/masbar-3.svg')}}" class="masbar3 fadeInDown animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/masbar/masbar-4.svg')}}" class="masbar4 fadeIn animated wow "
         style="animation-delay: 2.15s">
    <img src="{{asset('assets/images/products/masbar/masbar-5.svg')}}" class="masbar5 fadeIn animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/masbar/masbar-6.svg')}}" class="masbar6 fadeIn animated wow "
         style="animation-delay: 2.25s">
    <img src="{{asset('assets/images/products/masbar/masbar-7.svg')}}" class="masbar7 fadeInDown animated wow "
         style="animation-delay: 0.65s">
    <img src="{{asset('assets/images/products/masbar/masbar-8.svg')}}" class="masbar8 fadeIn animated wow "
         style="animation-delay: 2.5s">
    <img src="{{asset('assets/images/products/masbar/masbar-9.svg')}}" class="masbar9 fadeIn animated wow "
         style="animation-delay: 2.95s">
    <img src="{{asset('assets/images/products/masbar/masbar-10.svg')}}" class="masbar10 fadeInDown animated wow "
         style="animation-delay: 0.95s">
    <img src="{{asset('assets/images/products/masbar/masbar-11.svg')}}" class="masbar11 fadeIn animated wow "
         style="animation-delay: 2.85s">
    <img src="{{asset('assets/images/products/masbar/masbar-12.svg')}}" class="masbar12 fadeInLeft animated wow "
         style="animation-delay: 1.15s">
    <img src="{{asset('assets/images/products/masbar/masbar-13.svg')}}" class="masbar13 fadeIn animated wow "
         style="animation-delay: 2.20s">
    <img src="{{asset('assets/images/products/masbar/masbar-14.svg')}}" class="masbar14 fadeIn animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/masbar/masbar-15.svg')}}" class="masbar15 fadeIn animated wow "
         style="animation-delay: 2s">
</div>
