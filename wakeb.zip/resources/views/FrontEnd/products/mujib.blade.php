<div class="mb-5 mujib-animate">
    <img src="{{asset('assets/images/products/mujib/mujib1.svg')}}" class="mujib1 fadeInRight animated wow "
         style="animation-delay: 0.25s">
    <img src="{{asset('assets/images/products/mujib/mujib2.svg')}}" class="mujib2 fadeInDown animated wow "
         style="animation-delay: 0.5s">
    <img src="{{asset('assets/images/products/mujib/mujib3.svg')}}" class="mujib3 fadeInDown animated wow "
         style="animation-delay: 1s">
    <img src="{{asset('assets/images/products/mujib/mujib4.svg')}}" class="mujib4 fadeIn animated wow "
         style="animation-delay: 1.5s">
    <img src="{{asset('assets/images/products/mujib/mujib5.svg')}}" class="mujib5 fadeIn animated wow "
         style="animation-delay: 1.5s">
    <img src="{{asset('assets/images/products/mujib/mujib6.svg')}}" class="mujib6 bounceInRight animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/mujib/mujib7.svg')}}" class="mujib7 bounceInLeft animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/mujib/mujib8.svg')}}" class="mujib8 bounceInLeft animated wow "
         style="animation-delay: 2s">
    <img src="{{asset('assets/images/products/mujib/mujib9.svg')}}" class="mujib9 fadeIn animated wow "
         style="animation-delay: 3s">
    <img src="{{asset('assets/images/products/mujib/mujib10.svg')}}" class="mujib10 fadeIn animated wow "
         style="animation-delay: 2.75s">
    <img src="{{asset('assets/images/products/mujib/mujib11.svg')}}" class="mujib11 fadeIn animated wow "
         style="animation-delay: 3.25s">
    <img src="{{asset('assets/images/products/mujib/mujib12.svg')}}" class="mujib12 fadeIn animated wow "
         style="animation-delay: 3.50s">
    <img src="{{asset('assets/images/products/mujib/mujib13.svg')}}" class="mujib13 fadeIn animated wow "
         style="animation-delay: 3.20s">
</div>
